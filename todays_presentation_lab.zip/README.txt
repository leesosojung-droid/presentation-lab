오늘의 발표 연구소 - 배포 안내

파일 구성
- index.html : 독립형 웹사이트 파일

가장 쉬운 무료 배포 방법: GitHub Pages
1. https://github.com 에 로그인하거나 계정을 만듭니다.
2. 새 Repository를 만들고 이름을 presentation-lab 으로 지정합니다.
3. 공개(Public)로 설정하고 생성합니다.
4. Add file > Upload files를 눌러 index.html을 업로드하고 Commit changes를 누릅니다.
5. 저장소의 Settings > Pages로 이동합니다.
6. Build and deployment에서 Deploy from a branch를 선택합니다.
7. Branch는 main, 폴더는 /(root)를 선택하고 Save를 누릅니다.
8. 잠시 기다리면 https://깃허브아이디.github.io/presentation-lab/ 주소로 접속할 수 있습니다.

참고
- 별도 서버나 데이터베이스 없이 작동하는 정적 사이트입니다.
- 추첨 기록은 이용 중인 브라우저의 로컬 저장공간에 저장됩니다. 다른 기기와 기록이 자동 동기화되지는 않습니다.
- 주제는 중복 없이 추첨되며, 선택한 분야의 주제를 모두 뽑으면 해당 분야 안에서 다시 추첨할 수 있습니다.
